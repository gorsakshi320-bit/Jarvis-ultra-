# JARVIS ULTRA — Android-first PWA starter

This ZIP contains a functional starter app: responsive HUD, local conversation history, basic offline fallback, browser speech recognition/speech synthesis where supported, local tasks and notes, image preview, PWA manifest and service worker.

## Important limitations
- This is a working starter, not a full cinematic AI. Local fallback is intentionally limited.
- AI endpoint must be a trusted HTTPS backend accepting `POST` JSON `{ "message": "...", "mode": "...", "language": "..." }` and returning `{ "reply": "..." }` (or `response`/`message`). Do not put secret API keys in `app.js` or browser code.
- Image selection currently previews locally; it does not analyze the image.
- Browser apps cannot freely control Android apps/settings. Native Android Kotlin integration is required for additional supported controls.
- Wake word is not always-on; browser speech recognition starts only after the user taps the microphone.
- PWA install and microphone behavior require a secure HTTPS origin (localhost is also secure for development).

## Test locally
Open `index.html` in a browser for basic UI testing. For full PWA/service worker behavior, serve the folder over HTTPS.

## Publish free (phone-only)
1. Extract ZIP on your Android phone.
2. In GitHub, create a repository named `jarvis-ultra`.
3. Upload the extracted files preserving their names and folder structure. If mobile upload is difficult, use GitHub's browser desktop-site option or GitHub's upload-files page.
4. In repository Settings → Pages, choose deploy from branch, select `main` and `/ (root)`, then Save.
5. Wait for the HTTPS GitHub Pages URL. Open it in Chrome on Android.
6. Chrome menu → **Add to Home screen** or **Install app**.

## Make an APK on Android without a PC
### Option A — easiest: package the hosted PWA
1. First host the app at an HTTPS URL as above.
2. Open the official PWABuilder website in Chrome: https://www.pwabuilder.com/
3. Enter your hosted HTTPS URL and start the package/build flow.
4. Choose Android packaging (usually a Trusted Web Activity / Android package option when available).
5. Follow the current signing/build instructions provided by the service. Download the generated APK/AAB only after the build is completed successfully.
6. If an AAB is generated, it is generally intended for Play Console; use the service's supported APK output or follow its current Android build instructions for direct installation.
7. On your phone, open the APK download and allow installation from that source only if you trust the file. Review Android's warning and install.

PWABuilder's exact options can change. An HTTPS hosted PWA is required for this route. A wrapper will not magically add native phone-control capabilities; those need a native Kotlin app and runtime permissions.

### Option B — native Kotlin APK
A complete native APK build usually needs Android Gradle tooling. Without a PC, use a reputable Android IDE/build environment that actually supports Gradle APK builds, or a cloud build workflow. Do not upload signing keys, passwords, or private API keys to untrusted sites. Test the resulting APK before relying on it.

## Feature checklist
- [x] Responsive mobile UI and animated original HUD
- [x] Chat UI and limited local fallback responses
- [x] Browser speech recognition where supported
- [x] Browser text-to-speech where supported
- [x] Local tasks, notes, settings, conversation storage
- [x] Image preview without upload
- [x] PWA manifest and service worker
- [ ] Full LLM reasoning (configure trusted backend)
- [ ] Vision/OCR analysis backend
- [ ] Native Android integrations
- [ ] Continuous wake word
- [ ] Real offline LLM

## Privacy
Saved items use browser localStorage. Anyone with access to the same browser profile may be able to access them. Export data before clearing it. Do not enter sensitive data on a shared device.
